#!perl -wd:NYTProf
# a moose using script for profiling
# Usage: perl bench/profile.pl

require KiokuDB;
